module.exports = {
    token: "tokeni girin (zorunlu)", 
    prefix: "e!",
    botdavet: "(zorunlu)",
    desteksunucusu: "(zorunlu)",
    website: "(zorunlu)",
    topgg: "(zorunlu)",
    politika: "(zorunlu)",
    sunucuid: "(zorunlu)",
    destekçi: "(zorunlu)"
}

